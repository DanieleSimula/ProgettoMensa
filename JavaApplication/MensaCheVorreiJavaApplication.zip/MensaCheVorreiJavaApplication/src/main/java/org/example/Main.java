package org.example;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.CallableStatement;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/mensachevorrei";
        String user = "root";
        String password = "";

        try {
            Connection conn = DriverManager.getConnection(url, user, password);
            System.out.println("Connesso al database!");
            Scanner scanner = new Scanner(System.in);
            boolean continua = true;

            while (continua) {
                System.out.println("\n=== MENU TEST PROCEDURE ===");
                System.out.println("1. GetNotizie() - Visualizza tutte le notizie");
                System.out.println("2. get_piatti() - Visualizza tutti i piatti");
                System.out.println("3. getInfoStudente(nomeUtente) - Info complete studente");
                System.out.println("0. Esci");
                System.out.print("Scegli un'opzione: ");

                int scelta = 0;
                try {
                    scelta = scanner.nextInt();
                    scanner.nextLine(); // Consuma il newline
                } catch (Exception e) {
                    System.out.println("Input non valido!");
                    scanner.nextLine();
                    continue;
                }

                switch (scelta) {
                    case 1:
                        testGetNotizie(conn);
                        break;
                    case 2:
                        testGetPiatti(conn);
                        break;
                    case 3:
                        System.out.print("Inserisci il nome utente: ");
                        String username = scanner.nextLine();
                        testGetInfoStudente(conn, username);
                        break;
                    case 0:
                        continua = false;
                        System.out.println("Uscita dal programma...");
                        break;
                    default:
                        System.out.println("Opzione non valida!");
                }
            }

            conn.close();
            scanner.close();
            System.out.println("Connessione chiusa.");

        } catch (Exception e) {
            System.out.println("Il collegamento al database non è andato a buon fine.");
            System.out.println("Errore: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Test procedura GetNotizie
    private static void testGetNotizie(Connection conn) {
        try {
            System.out.println("\n=== ESECUZIONE: CALL GetNotizie() ===");
            CallableStatement stmt = conn.prepareCall("{CALL GetNotizie()}");
            ResultSet rs = stmt.executeQuery();

            stampaRisultati(rs);

            rs.close();
            stmt.close();
        } catch (Exception e) {
            System.out.println("Errore durante l'esecuzione della procedura: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Test procedura get_piatti
    private static void testGetPiatti(Connection conn) {
        try {
            System.out.println("\n=== ESECUZIONE: CALL get_piatti() ===");
            CallableStatement stmt = conn.prepareCall("{CALL get_piatti()}");
            ResultSet rs = stmt.executeQuery();

            stampaRisultati(rs);

            rs.close();
            stmt.close();
        } catch (Exception e) {
            System.out.println("Errore durante l'esecuzione della procedura: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Test procedura getInfoStudente
    private static void testGetInfoStudente(Connection conn, String nomeUtente) {
        try {
            System.out.println("\n=== ESECUZIONE: CALL getInfoStudente('" + nomeUtente + "') ===");
            CallableStatement stmt = conn.prepareCall("{CALL getInfoStudente(?)}");
            stmt.setString(1, nomeUtente);
            ResultSet rs = stmt.executeQuery();

            stampaRisultati(rs);

            rs.close();
            stmt.close();
        } catch (Exception e) {
            System.out.println("Errore durante l'esecuzione della procedura: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Metodo helper per stampare i risultati
    private static void stampaRisultati(ResultSet rs) throws Exception {
        int colCount = rs.getMetaData().getColumnCount();

        // Stampa header con i nomi delle colonne
        System.out.println("\n--- RISULTATI ---");
        for (int i = 1; i <= colCount; i++) {
            System.out.print(rs.getMetaData().getColumnName(i) + " | ");
        }
        System.out.println();
        System.out.println("─".repeat(80));

        // Stampa righe
        int rowCount = 0;
        while (rs.next()) {
            for (int i = 1; i <= colCount; i++) {
                System.out.print(rs.getObject(i) + " | ");
            }
            System.out.println();
            rowCount++;
        }

        System.out.println("─".repeat(80));
        System.out.println("Totale righe: " + rowCount);
    }
}
